import math
#from math import *         se importan todas las funciones de la biblioteca
#from math import cos,pi    se importan solo las funciones que se necesitan
#import math as ma          permite poner un alias a la boblioteca importada
#x = ma.cos(ma.pi)

x = math.cos(math.pi)

print(x)

#la funcuion dir permite conocer las funciones existentes en una biblioteca
#previamente importada
print(dir(math))

#la funcion help permite conocer el como usar las funciones
help(math.log)

input()
