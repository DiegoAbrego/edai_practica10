def obtenerMayor(n1,n2):
    #compara ambas variables y si la comparacion
    #resulta verdadera ejecuta la instruccion
    if n1 < n2:
        print(str(n1)+" es menor que "+str(n2))

obtenerMayor(3,7)

obtenerMayor(7,3)
#no imprime nada ya que la condicion es falsa

x = y = z = 3
if x == y == z:
    #Se muestra como se puede agregar mas de una condicion
    print(True)

input()
