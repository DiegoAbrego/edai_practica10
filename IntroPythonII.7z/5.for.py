for x in [1,2,3,4,5]:
    #se itera el valor de x automaticamente recorriendo la lista
    print (x)

#funcion range genera una lista
#se genera la lista que inicia en 0 y hasta antes del numero indicado
for x in range(5):
    print(x)

#en este caso inicia en el -5 y llega hasta el 1
for x in range(-5,2):
    print(x)

for num in ["uno","dos","tres","cuatro"]:
    print (num)

input()
